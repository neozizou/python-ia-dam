# Python aplicado a la Inteligencia Artificial

Módulo optativo de **2.º de Desarrollo de Aplicaciones Multiplataforma (DAM)** · Curso 2026-2027

Materiales del módulo: apuntes de cada unidad, listados de código ejecutables y datos de ejemplo. El módulo se imparte del 16/09/2026 al 16/02/2027, con 3 horas semanales (53 horas lectivas según el calendario escolar de Granada).

## Unidades didácticas

| UD | Contenido | Horas | Fechas aprox. | Estado |
| --- | --- | --- | --- | --- |
| [UD1](ud1-python/) | Python para quien ya programa | 7 | 21/09 – 05/10 | Disponible |
| UD2 | Programación orientada a objetos en Python | 5 | 05/10 – 19/10 | Próximamente |
| UD3 | Análisis de datos con Python y primer despliegue con Streamlit | 10 | 20/10 – 16/11 | Próximamente |
| UD4 | SQL y NoSQL desde Python | 4 | 17/11 – 24/11 | Próximamente |
| UD5 | Big Data | 5 | 30/11 – 14/12 | Próximamente |
| UD6 | Machine Learning con scikit-learn | 10 | 15/12 – 19/01 | Próximamente |
| UD7 | Proyecto integrador, despliegue y evaluación | 9 | 25/01 – 16/02 | Próximamente |

## Resultados de aprendizaje

1. Implementa programas básicos en Python aplicados a la manipulación de datos.
2. Utiliza herramientas de análisis y procesamiento de datos con Python.
3. Aplica conceptos básicos de Machine Learning en problemas reales.
4. Comprende los principios del Big Data y su aplicación práctica en el análisis de datos.

## Cómo usar este repositorio

Necesitas **Python 3.14** y **VS Code** con las extensiones Python y Jupyter. La UD1 explica paso a paso cómo instalarlos.

```bash
git clone https://github.com/neozizou/python-ia-dam.git
cd python-ia-dam
python -m venv .venv
# Windows (PowerShell):   .venv\Scripts\Activate.ps1
# macOS / Linux:          source .venv/bin/activate
```

Cada unidad tiene su propia carpeta con la misma estructura:

```text
udN-tema/
├── README.md      apuntes de la unidad
├── listados/      los listados de los apuntes como ficheros .py ejecutables
└── proyecto/      código de ejemplo completo, cuando la unidad lo necesita
```

Los listados se ejecutan desde su carpeta `listados/`, para que las rutas a `datos/` funcionen.

## Proyecto integrador

A lo largo del curso cada alumno o equipo trabaja siempre con el mismo conjunto de datos real:

| Hito | Unidad | Qué se hace con el conjunto de datos |
| --- | --- | --- |
| 0 | UD1 | Elegirlo y describirlo con Python puro |
| 1 | UD3 | Limpiarlo, explorarlo y publicar un primer panel con Streamlit |
| 2 | UD4 | Guardarlo en una base de datos y consultarlo |
| 3 | UD5 | Tratarlo como problema de escala |
| 4 | UD6 | Entrenar, evaluar y ajustar un modelo |
| 5 | UD7 | Desplegar la aplicación con el modelo y defenderla |
